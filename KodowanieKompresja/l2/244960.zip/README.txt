Program realizuje klasyczne kodowanie Huffmana. 


W pliku "test.py" istnieje tablica do ktorej trzeba wpisac pliki do zakodowania i odkodowania. Sciezka do pliku moze byc dowolna.
Uruchamiać poleceniem "python test.py" lub "python3 test.py"