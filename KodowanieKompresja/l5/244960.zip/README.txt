Program realizujacy pierwsze polecenie.

Uruchamiać poleceniem 'python kwantyzacja.py plik_wejsciowy plik_wyjsciowy r g b', gdzie r, g, b są ilością bitów na kolor w zakresie 0-8.
Program nie sprawdza, czy dane wejsciowe są błedne.